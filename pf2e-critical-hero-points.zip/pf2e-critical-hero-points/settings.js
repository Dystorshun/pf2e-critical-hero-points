export const registerSettings = function() {
  // Add settings here if needed later.  Example:
  // game.settings.register("pf2e-critical-hero-points", "awardOnCrit", {
  //   name: "Award on Critical Hit?",
  //   hint: "Award a hero point on a critical hit?",
  //   scope: "world",
  //   config: true,
  //   type: Boolean,
  //   default: true,
  // });
};
